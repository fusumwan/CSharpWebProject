﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PCCW.RWL.CORE
{

    public enum CurrentLockStatus
    {
        ISSUE_ORDER,
        MODIFY_ORDER
    }
}
