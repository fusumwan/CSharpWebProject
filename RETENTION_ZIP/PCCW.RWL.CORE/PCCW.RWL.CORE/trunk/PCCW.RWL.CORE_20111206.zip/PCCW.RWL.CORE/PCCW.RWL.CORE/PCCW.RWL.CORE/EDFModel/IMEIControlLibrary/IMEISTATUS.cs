﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PCCW.RWL.CORE
{
    public class IMEISTATUS
    {
        public const string NORMAL = "NORMAL";
        public const string SOLD = "SOLD";
        public const string STOCK = "STOCK";
        public const string AWAIT = "AWAIT";
        public const string AO = "AO";
    }
}
